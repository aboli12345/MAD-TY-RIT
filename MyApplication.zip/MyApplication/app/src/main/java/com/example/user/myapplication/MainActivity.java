package com.example.user.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("onCreate()","Activity created");

    }
    protected void onStart(){
        super.onStart();
        Log.i("onStart()","Activity started");
    }
    protected void onResume(){
        super.onResume();
        Log.i("onResume()","Activity resumed");
    }
    protected void onStop(){
        super.onStop();
        Log.i("onStop()","Activity stopped");
    }
    protected void onRestart(){
        super.onRestart();
        Log.i("onRestart()","Activity restarted");
    }
    protected void onPause(){
        super.onPause();
        Log.i("onPause()","Activity paused");
    }
    protected void onDestroy(){
        super.onDestroy();
        Log.i("onDestroy()","Activity destroyed");
    }
}
