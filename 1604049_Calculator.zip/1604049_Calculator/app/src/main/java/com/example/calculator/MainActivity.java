package com.example.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b_add,b_sub,b_mul,b_div;
    EditText ed1,ed2;
    TextView ans;
    int a,b;
    public boolean numget() {
        if(ed1.getText().toString().isEmpty() && ed2.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter both of the operands", Toast.LENGTH_SHORT).show();
            ans.setText("");
            return false;
        }
        else if(ed1.getText().toString().isEmpty() || ed2.getText().toString().isEmpty()) {

            if (ed1.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please enter a", Toast.LENGTH_SHORT).show();

            }

            else  {
                Toast.makeText(this, "Please enter b", Toast.LENGTH_SHORT).show();
            }
            ans.setText("");
            return false;
        }

        if (!ed1.getText().toString().isEmpty() && !ed2.getText().toString().isEmpty()) {
            a = Integer.parseInt(ed1.getText().toString());
            b = Integer.parseInt(ed2.getText().toString());
            return true;
        }
        else
            return false;
    }

    public void add(View view) {
        if (numget()) {
            int result = a + b;
            ans.setText("Addition is " + result);
        }
    }
    public void sub(View view)
    {
        if(numget()) {
            int result = a - b;
            ans.setText("Subtraction is " + result);
        }
    }
    public void mul(View view)
    {
        if(numget()) {
            int result = a * b;
            ans.setText("Multiplication is " + result);
        }
    }
    public void div(View view)
    {
        if(numget()) {
            int result = a / b;
            ans.setText("Division is " + result);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b_add=findViewById(R.id.addButton);
        ed1=findViewById(R.id.editText1);
        ed2=findViewById(R.id.editText2);
        ans=findViewById(R.id.anstextView);
    }
}
