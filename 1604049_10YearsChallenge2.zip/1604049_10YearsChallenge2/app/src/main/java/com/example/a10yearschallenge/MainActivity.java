package com.example.a10yearschallenge;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView wtext;
    ImageView iv;
    public void tenyr(View view)
    {
        iv.setImageResource(R.drawable.after);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent i=getIntent();
        String username=i.getStringExtra("Username");
        String password=i.getStringExtra("Password");
        String role=i.getStringExtra("Role");
        wtext=findViewById(R.id.wtext);
        iv=findViewById(R.id.imageView);
        wtext.setText(username+"("+role+")");
    }
}
